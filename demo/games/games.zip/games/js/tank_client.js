var Tank = Tank || {};

/**************util*************/
//基本的工具类
Tank.Point = function(x, y){
    if(x instanceof Tank.Point) {
        this.x = x.x;
        this.y = x.y;
    }else{
        this.x = x;
        this.y = y;
    }
}
Tank.collide = function(a, b){
    if((a.loc_.x + a.size_.x > b.loc_.x )&&( a.loc_.x < b.loc_.x + b.size_.x)
            && (a.loc_.y + a.size_.y > b.loc_.y) && (a.loc_.y < b.loc_.y + b.size_.y)){ 
        return true;

    }
    else return false;
}
// a% 的概率返回true
Tank.rand = function(a){
    if(Math.random()*100 < a) return true;
    return false;
}
/*put b in the center of a*/
Tank.center = function(a, b ){
    b.loc_.x = a.loc_.x + a.size_.x/2 - b.size_.x/2;
    b.loc_.y = a.loc_.y + a.size_.y/2 - b.size_.y/2;
}
/*************static values************/
Tank.canvas_ = null;
Tank.size_ = new Tank.Point(800, 600);
Tank.refresh_ = 50;
Tank.window_ = document;
Tank.listenBody_ = document;
Tank.timer_ = new goog.Timer(Tank.refresh_);
Tank.status_ = "stop"; //stop,run, pause
Tank.globalMessage_ = null;


/***************TankClient**************/
Tank.TankClient = function(){
    Tank.Panel.init(goog.dom.getElement("panel"));
}
goog.inherits(Tank.TankClient, goog.ui.Component);
Tank.TankClient.prototype.decorateInternal = function(element){
    this.element_ = element;
    this.canvas_ = Tank.canvas_ = this.element_.getContext("2d");
    element.style.width = Tank.size_.x;
    element.style.height = Tank.size_.y;
    this.init();
}

Tank.TankClient.prototype.init = function(){
    //test
    Tank.globalMessage_ = new Tank.Message(Tank.canvas_, "PAUSE", null, null, "rgb(255, 0, 0)", -1)
    this.sceneManager_ = Tank.SceneManager;
    this.sceneManager_.push(Tank.globalMessage_);
    this.mapManager_ = Tank.MapManager;

    var lastStyle = this.canvas_.fillStyle;
    this.canvas_.fillStyle = "rgb(0, 0, 0)";
    this.canvas_.fillText("HTML5 GAME v0.1。", 300, 200);
    this.canvas_.fillStyle = "rgb(255, 0, 0)";
    this.canvas_.fillText("" +
            "按键说明： 方向键移动，A 发射子弹，P暂停游戏，" +
            "按空格开始游戏,。" +
            "未完，待续⋯⋯" +
            "", 100, 250);
    this.canvas_.fillStyle = lastStyle;

}
Tank.TankClient.prototype.enterDocument = function(){
    this.getHandler().listen(Tank.timer_, goog.Timer.TICK, this.act);
    this.getHandler().listen(Tank.listenBody_, goog.events.EventType.KEYDOWN, this.onKeyDown);
    this.getHandler().listen(Tank.listenBody_, goog.events.EventType.KEYUP, this.onKeyUp);
}
Tank.TankClient.prototype.act = function(){
    this.canvas_.fillRect(0, 0, Tank.size_.x, Tank.size_.y);
    this.sceneManager_.act();
}

Tank.TankClient.prototype.onKeyDown = function(e){
    switch(e.keyCode){
        case(goog.events.KeyCodes.P): //game pause 
           this.pause(); 
           break;
        case(goog.events.KeyCodes.SPACE): //game pause 
           this.start(); 
           break;
    }
}
Tank.TankClient.prototype.onKeyUp = function(e){
}
Tank.TankClient.prototype.start = function(){
    if(Tank.status_ == "stop") {
        this.mapManager_.start();
        Tank.status_ = "run";
        Tank.timer_.start();
    }
}
//pause/unpause the game
Tank.TankClient.prototype.pause = function(){ 
    if(Tank.status_ == "run"){
        Tank.timer_.stop();
        Tank.status_ = "pause";
        var lastStyle = this.canvas_.fillStyle;
        this.canvas_.fillStyle = "rgb(255, 0, 0)";
        this.canvas_.fillText("PAUSE", 100, 90);
        this.canvas_.fillStyle = lastStyle;
    }else if(Tank.status_ == "pause"){
        Tank.timer_.start();
        Tank.status_ = "run";
    }
}
Tank.TankClient.prototype.stop = function(){
}


/****************SceneManager**************/
//管理所有的物体，负责通知每个物体执行刷新操作，负责剔除死亡物体。
//负责一切查找物体的操作
Tank.SceneManager = {}
Tank.SceneManager.all_ = [];
Tank.SceneManager.refreshCount_ = 0;    //用来记录是不是过了一秒钟
Tank.SceneManager.setAll = function(all){
    Tank.SceneManager.all_ = all;

}
Tank.SceneManager.push = function(obj){
    Tank.SceneManager.all_.push(obj);
}
Tank.SceneManager.act = function(){
    var all = Tank.SceneManager.all_;
    
    for(var i = 0; i < all.length; i++){
        if(all[i].alive_ == false) {
            all[i].die();
            all.splice(i,1);
            i--;//注意此处，不然后面的一个物体会少显示一次导致画面闪一下
            continue;
        }
        //碰撞检测
        for(var j = 0; j < all.length; j++){
            if(i == j) continue;
            if((all[i].isBarrier4Walk_ || all[i].isBarrier4Bullet_) && (all[j].isBarrier4Walk_ ||all[j].isBarrier4Bullet_))
            if(Tank.collide(all[i], all[j])){
                if(all[i].hit) all[i].hit(all[j]);
                if(all[j].beHit) all[j].beHit(all[i]);
            }
        }
        Tank.SceneManager.all_[i].act();
        if(Tank.SceneManager.refreshCount_ <= 0){
            Tank.SceneManager.all_[i].tick();
        }
    }
    if( Tank.SceneManager.refreshCount_ <= 0) {
        Tank.SceneManager.refreshCount_ = 1000/Tank.refresh_
    }
    Tank.SceneManager.refreshCount_ --;    //用来记录是不是过了一秒钟
}
//获得指定圆形范围内的所有物体
Tank.SceneManager.getObjsInScope = function(loc, radius){
    var all = Tank.SceneManager.all_;
    var result = []
    var loc2;
    for(i in all){
        loc2 = all[i].loc_;
        if( Math.sqrt(Math.pow((loc.x - loc2.x), 2) + Math.pow((loc.y - loc2.y), 2)) < radius){
            result.push(all[i]);
        }
    }
    return result;
}
/*****************MapManager*****************/
//负责加载地图
Tank.MapManager = {};
Tank.MapManager.canvas_ = Tank.canvas_;
Tank.MapManager.sceneManager_ = Tank.SceneManager;
Tank.MapManager.maps_ = []
Tank.MapManager.index_ = 0;
Tank.MapManager.currentMap_ = null;

Tank.MapManager.init = function(){
}

Tank.MapManager.start = function(){
    Tank.MapManager.index_ = 0;
    this.load(Tank.MapManager.index_);
}
Tank.MapManager.next = function(){
    this.load( ++ Tank.MapManager.index_ );
}
//加载指定关卡
Tank.MapManager.load = function(index){
    Tank.MapManager.index_ = index;
    Tank.MapManager.currentMap_ = Tank.MapManager.maps_[index];
    this.parseMap(Tank.MapManager.currentMap);
}

Tank.MapManager.parseMap = function(map){
    this.sceneManager_.setAll([new Tank.MainTank()]);
    this.sceneManager_.push(new Tank.Rock(new Tank.Point(50, 50)));
    this.sceneManager_.push(new Tank.Rock(new Tank.Point(50, 100)));
    this.sceneManager_.push(new Tank.Rock(new Tank.Point(100, 100)));
    this.sceneManager_.push(new Tank.Rock(new Tank.Point(200, 100)));
    this.sceneManager_.push(new Tank.SteelRock(new Tank.Point(300, 400)));
    this.sceneManager_.push(new Tank.SteelRock(new Tank.Point(350, 400)));
    this.sceneManager_.push(new Tank.SteelRock(new Tank.Point(400, 400)));

    this.sceneManager_.push(new Tank.Tree(new Tank.Point(200, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(250, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(300, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(350, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(400, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(450, 200)));
    this.sceneManager_.push(new Tank.Tree(new Tank.Point(500, 200)));

    this.sceneManager_.push(new Tank.Food(new Tank.Point(200, 300)));
    this.sceneManager_.push(new Tank.Equip(new Tank.Point(300, 300)));
    this.sceneManager_.push(new Tank.Equip1(new Tank.Point(350, 300)));
    this.sceneManager_.push(new Tank.Equip2(new Tank.Point(400, 300)));
    this.sceneManager_.push(new Tank.Equip3(new Tank.Point(450, 300)));
    this.sceneManager_.push(new Tank.Equip4(new Tank.Point(500, 300)));

    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
    this.sceneManager_.push(new Tank.RandomTank(new Tank.Point(200,300)));
}

/**************控制面板**********/
Tank.Panel = {};
Tank.Panel.panel_ = null;
Tank.Panel.init = function(panel){
    Tank.Panel.panel_ = panel;
}
Tank.Panel.act = function(){
    Tank.Panel.draw();
}
Tank.Panel.draw = function(){
    var canvas = Tank.Panel.panel_.getContext("2d");
    if(!canvas) return;
}
/****************BaseObject**************/
/*
   object基础，有
   */
Tank.BaseObject = function(canvas, name, size, loc, imgs, opt_isBarrier4Walk, opt_changeImageTime, opt_zindex){
    this.canvas_ = canvas;
    this.imgs_ = imgs || [];
    this.size_ = size || new Tank.Point(50, 50);
    this.loc_ = loc || new Tank.Point(0, 0);
    this.alive_ = true;
    this.visible_ = true;
    this.name_ = name || "unnamed baseObject";
    this.isBarrier4Walk_ = opt_isBarrier4Walk || true;
    this.isBarrier4Bullet_ = true;
    this.changeImageTime_ = opt_changeImageTime || 2;
    this.changeImageCount_ = this.changeImageTime_;
    this.imgIndex_ = -1;
    this.zindex = 0;
    this.camp_ = 0; //0: 中立，会挡住两方的子弹，1：友军，2：敌军
    this.hp_ = 200;  //当前的生命值 
    this.hpLimit_ = 200;    //
    this.hpRecover_ = 0; //每秒钟自动回复生命
    this.protect_ = 0; //护甲
    this.invincible_ = false; //无敌状态，受到
    this.showBloodBar_ = false;
    this.missProb_ = 0;   //闪避攻击的概率
    this.ais_ = []; //一个物体可以有多个ai
    this.sceneManager_ = Tank.SceneManager; //保存一个引用
    this.init();
}
goog.inherits(Tank.BaseObject, goog.ui.Component);
Tank.idCounter_ = 0;//用来产生唯一的id标志
Tank.BaseObject.prototype.init = function(){
    this.id_ = ++Tank.idCounter_;
}
//每次页面刷新都会执行的操作
Tank.BaseObject.prototype.act = function(){
    this.go();
    this.draw();
}
//每隔一秒执行一次
Tank.BaseObject.prototype.tick = function(){
    for(i in this.ais_) this.ais_[i].tick();
    this.cure(this.hpRecover_, false);
}
Tank.BaseObject.prototype.beHit = function(obj){
    for(i in this.ais_) this.ais_[i].beHit(obj);
    
    if(this.missBullet_){
        this.missBullet_ = false;
    }else{
        if(obj.power_ && obj.camp_ != this.camp_){
            if(Tank.rand(this.missProb_)){
                this.popMessage("闪避");

            }else{
                var computedPower = (obj.power_ > this.protect_ ? obj.power_ - this.protect_ : 0);
                this.beHarmed(computedPower, obj, true);
            }
        }
    }
}
Tank.BaseObject.prototype.popMessage = function(m){
    Tank.SceneManager.push(new Tank.Message(this.canvas_, m, null, new Tank.Point(this.loc_), "rgb(255, 0, 0)")); 
}
//恢复生命值
Tank.BaseObject.prototype.cure = function(n, showMessage){
    if(this.hp_ < this.hpLimit_){
        var diff = this.hpLimit_ - this.hp_;
        var cn = diff < n ? diff : n;
        this.hp_ += cn;
        if(showMessage) this.popMessage("+" + cn);
    }

}
//受到伤害，损失生命 <=0 则死亡
//无敌状态不会损失生命
Tank.BaseObject.prototype.beHarmed = function(n, obj, showMessage){
    if(this.invincible_) return;//无敌状态
    this.hp_ -= n;
    if(this.hp_ <= 0) this.alive_ = false;
    if(showMessage) this.popMessage("-" + n);
    if(obj.isBullet_ ) obj = obj.owner_; //子弹的伤害，来源是发射子弹的物体
    if(obj && obj.harm) obj.harm(n, this); //伤害成功
}

//设置闪避概率，不可叠加，默认选中最大值
Tank.BaseObject.prototype.setMissProb = function(n){
    if(n > this.missProb_ ) this.missProb_ = n;
}
//临死前执行的动作
Tank.BaseObject.prototype.die = function(){
    
}
Tank.BaseObject.prototype.go = function(){
    for(i in this.ais_) {
        this.ais_[i].go();
    }
}

Tank.BaseObject.prototype.draw = function(){
    this.changeImage();
    if(this.currentImg_){
        this.canvas_.drawImage(this.currentImg_, this.loc_.x, this.loc_.y, this.size_.x, this.size_.y);
    }
    //draw bloodbar
    if(!this.invincible_ && this.showBloodBar_){
        var lastStyle = this.canvas_.fillStyle;
        this.canvas_.fillStyle = "rgb(0, 0, 255)";
        this.canvas_.fillRect(this.loc_.x, this.loc_.y - 20, 50, 8);

        if(this.hp_ >= this.hpLimit_/3*2)
            this.canvas_.fillStyle = "rgb(0, 255, 0)";
        else if(this.hp_ >= this.hpLimit_/3*1)
            this.canvas_.fillStyle = "rgb(255, 255, 0)";
        else 
            this.canvas_.fillStyle = "rgb(255, 0, 0)";

        this.canvas_.fillRect(this.loc_.x, this.loc_.y - 20, 50 * (this.hp_ / this.hpLimit_), 8);
        this.canvas_.fillStyle = lastStyle;
    }
}

Tank.BaseObject.prototype.changeImage = function(){
    if(this.changeImageCount_ < 0){
        this.imgIndex_ ++;
        if(this.imgIndex_ >= this.imgs_.length)
            this.imgIndex_ = 0;
        this.changeImageCount_ = this.changeImageTime_;
    }else{
    }
    this.currentImg_ = this.imgs_[this.imgIndex_];
    this.changeImageCount_ --;
}

/************Movable*************/

Tank.Movable = function(canvas, imgsAll){
    this.canvas_ = canvas;
    this.imgsAll_ = imgsAll;
    if(!this.imgsAll_){
        var imgsU = [];
        var img = new Image();
        img.src = "img/tankU.gif";
        imgsU.push(img);
        var imgsR = [];
        var img = new Image();
        img.src = "img/tankR.gif";
        imgsR.push(img);
        var imgsD = [];
        var img = new Image();
        img.src = "img/tankD.gif";
        imgsD.push(img);
        var imgsL = [];
        var img = new Image();
        img.src = "img/tankL.gif";
        imgsL.push(img);

        this.imgsAll_ = [];
        this.imgsAll_.push(imgsU,imgsR, imgsD, imgsL);
    }

    Tank.Movable.superClass_.constructor.call(this, this.canvas_, "Tank", null, new Tank.Point(100, 100), imgsU, true, 0);

    this.isBarrier4Walk_ = false;
    this.moveDirec_ = 0;//0123 上右下左
    this.moveSpeed_ = 5;
    this.enableMove_ = true; //
    this.moving_ = false;
    this.canEatFood_ = false;
    this.lastLoc_ = new Tank.Point(this.loc_);
    this.ais_.push(new Tank.MovableAI(this));
    this.equips_ = [];
}
goog.inherits(Tank.Movable, Tank.BaseObject);

Tank.Movable.prototype.hit = function(obj){
    for(i in this.ais_) this.ais_[i].hit(obj);
}
Tank.Movable.prototype.go = function(){
    Tank.Movable.superClass_.go.call(this);
    for(i in this.equips_) this.equips_[i].go();
}
Tank.Movable.prototype.tick = function(){
    Tank.Movable.superClass_.tick.call(this);
    for(i in this.equips_) this.equips_[i].tick();
}
Tank.Movable.prototype.beHit = function(obj){
    for(i in this.equips_) this.equips_[i].beHit(obj);
    Tank.Movable.superClass_.beHit.call(this, obj);
}
Tank.Movable.prototype.move = function(direct){
    if(direct != undefined) this.moveDirec_ = direct;
    this.moving_ = true;
}
Tank.Movable.prototype.stop = function(direct){
    this.moving_ = false;
}

/*****************FireMovable*************/
Tank.FireMovable = function(canvas, move_imgs, Bullet){
    Tank.FireMovable.superClass_.constructor.call(this, canvas, move_imgs);
    
    this.enableFire_ = true;
    this.firing_ = false;
    this.fireDirec_ = 0;
    this.fireSpeed_ = 10; //
    this.fireSpeedCount_ = 0;
    this.bulletSpeed_ = 10;
    this.Bullet_ = Bullet || Tank.Bullet;
    this.bullerPower_ = 10;
    this.crit_ = 200 ; //暴击伤害 默认是2倍暴击
    this.critProb_ = 0;//暴击概率，默认为0
}
goog.inherits(Tank.FireMovable, Tank.Movable);

Tank.FireMovable.prototype.act = function(direc){
    Tank.FireMovable.superClass_.act.call(this);
    this.fireDirec_ = this.moveDirec_;
    if(this.fireSpeedCount_ <= 0){
        if(this.firing_ && this.enableFire_){
             this.fire();
             this.fireSpeedCount_ = this.fireSpeed_;
        }
    }else{
        this.fireSpeedCount_ --;
    }
}
//成功对另一个单位造成伤害后的回调函数
//参数：伤害数值,被伤害的对象
Tank.FireMovable.prototype.harm = function(num, obj){
    for(i in this.ais_) {
        this.ais_[i].harm(num, obj);
    }
    for(i in this.equips_) this.equips_[i].harm(num, obj);
}
Tank.FireMovable.prototype.fire  = function(){
    var computedBulletPower = this.bulletPower_;
    if(Tank.rand(this.critProb_)){
        computedBulletPower *= parseInt(this.crit_ / 100);
        this.popMessage("暴击 " + this.crit_ + "%");
    }
    for(i in this.equips_) this.equips_[i].fire();
    var bullet = new this.Bullet_(this.canvas_, this.camp_, computedBulletPower,  this.fireDirec_, new Tank.Point(this.loc_), this.bulletSpeed_)
    Tank.center(this, bullet);
    bullet.owner_ = this;
    Tank.SceneManager.push(bullet);
}
Tank.FireMovable.prototype.startFire  = function(direc){
        this.firing_ = true;
}
Tank.FireMovable.prototype.stopFire  = function(){
    this.firing_ = false;
}

/******************KeyMovable*************/
/**************Bullet************/
Tank.Bullet = function(canvas, camp, power, direc, loc, speed){
    Tank.Bullet.superClass_.constructor.call(this, canvas, "bullet");
        var imgsU = [];
        var img = new Image();
        img.src = "img/missileU.gif";
        imgsU.push(img);
        var imgsR = [];
        var img = new Image();
        img.src = "img/missileR.gif";
        imgsR.push(img);
        var imgsD = [];
        var img = new Image();
        img.src = "img/missileD.gif";
        imgsD.push(img);
        var imgsL = [];
        var img = new Image();
        img.src = "img/missileL.gif";
        imgsL.push(img);

        this.imgsAll_ = [];
        this.imgsAll_.push(imgsU,imgsR, imgsD, imgsL);
    this.loc_ = loc;
    this.moveDirec_ = direc;
    this.moving_ = true;
    this.moveSpeed_ = speed || 10;
    this.size_ = new Tank.Point(10,10);
    this.camp_ = camp;
    this.power_ = power || 10;
    this.type_ = "bullet";
    this.isBullet_ = true;
    this.isBarrier4Walk_ = true;
    this.isBarrier4Bullet_ = false;
    this.owner_ = null; //子弹的发出者
}
goog.inherits(Tank.Bullet, Tank.Movable);
Tank.Bullet.prototype.hit = function(obj){
    if(this.camp_ != obj.camp_ && obj.isBarrier4Bullet_){
        this.alive_ = false;
    }

}

Tank.Bullet.prototype.beHit = function(bullet){
    
}
/*************各种障碍物**************/
Tank.Rock = function(loc){
       Tank.Rock.superClass_.constructor.call(this, Tank.canvas_, "rock", undefined, loc); 
       var img = new Image();
       img.src = "img/rock_0.ico";
       this.imgs_ = [img];
       this.camp_ = 0;
       this.showBloodBar_ = true;
}
goog.inherits(Tank.Rock, Tank.BaseObject);


Tank.SteelRock = function(loc){
       Tank.SteelRock.superClass_.constructor.call(this, Tank.canvas_, "rock", undefined, loc); 
       var img = new Image();
       img.src = "img/walls/wall0.png";
       this.imgs_ = [img];
       this.camp_ = 0;
       this.invincible_ = true;
}
goog.inherits(Tank.SteelRock, Tank.BaseObject);

Tank.Tree = function(loc){
       Tank.Tree.superClass_.constructor.call(this, Tank.canvas_, "rock", undefined, loc); 
       var img = new Image();
       img.src = "img/tree_0.ico";
       this.imgs_ = [img];
       this.camp_ = 0;
       this.isBarrier4Bullet_ = false;
       this.invincible_ = true;
}
goog.inherits(Tank.Tree, Tank.BaseObject);

/**************message************/
Tank.Message = function(canvas,  text, size, loc, color, time){
    Tank.Message.superClass_.constructor.call(this, canvas, "message", size, loc)
    this.color_ = color || "rgb(255, 0, 0)";
    this.text_ = text;
    this.time_ = time || 30; //
    this.isBarrier4Bullet_ = false;
    this.isBarrier4Walk_ = false;
}

goog.inherits(Tank.Message, Tank.BaseObject);

Tank.Message.prototype.go = function(){
        this.time_ --;
        if(this.time_ <= 0) this.alive_ = false;
        this.loc_.y -= 1;
}
Tank.Message.prototype.draw = function(){
    var lastStyle = this.canvas_.fillStyle;
    this.canvas_.fillStyle = this.color_;
    this.canvas_.fillText(this.text_, this.loc_.x, this.loc_.y);
    this.canvas_.fillStyle = lastStyle;
}
Tank.Message.prototype.beHit = function(){
}
Tank.Message.prototype.hit = function(){

}

/*******爆炸动画*********/
Tank.Explode = function(loc){
    Tank.Food.superClass_.constructor.call(this, Tank.canvas_, "explode", null, loc); 
    this.isBarrier4Bullet_ = false;
    this.isBarrier4Walk_ = false;
    for(var i = 0; i < 11; i++){
        var img = new Image();
        img.src = "img/" + i + ".gif";
        this.imgs_.push(img);
    }
    this.time_ = 30; //持续时间
}
goog.inherits(Tank.Explode, Tank.BaseObject);
Tank.Explode.prototype.go = function(){
    Tank.Explode.superClass_.go.call(this);
    this.time_ --;
    if(this.time_ < 0) this.alive_ = false;
}
/********food*********/
//一个回复满血的大膏药作为基础类，其他食物可以继承此类，只需要设置自己的图片和重写feed方法即可
Tank.Food = function(loc){
    Tank.Food.superClass_.constructor.call(this, Tank.canvas_, "food-" + this.type_, null, loc); 
    this.size_ = new Tank.Point(40, 40);
    this.isFood_ = true;
    this.time_ = 50; //食物持续时间
    var img = new Image();
    img.src = "img/food/food_0.gif";
    this.imgs_ = [img];
    this.isBarrier4Bullet_ = false;
    this.isBarrier4Walk_ = true;
}
goog.inherits(Tank.Food, Tank.BaseObject);
Tank.Food.prototype.tick = function(){
    Tank.Food.superClass_.tick.call(this);
    this.time_ --;
    if(this.time_ < 0) this.alive_ = false;

}
Tank.Food.prototype.go = function(){
    Tank.Food.superClass_.go.call(this);
}
Tank.Food.prototype.draw = function(){
    Tank.Food.superClass_.draw.call(this);
    var lastStyle = this.canvas_.fillStyle;
    this.canvas_.fillStyle = "rgb(255, 0, 0)";
    this.canvas_.strokeRect(this.loc_.x, this.loc_.y, this.size_.x, this.size_.y);
    this.canvas_.fillText(parseInt(this.time_) + "", this.loc_.x, this.loc_.y + this.size_.y + 15);
    this.canvas_.fillStyle = lastStyle;
}
Tank.Food.prototype.beHit = null

Tank.Food.prototype.feed = function(obj){
    if(obj.hp_ != undefined){
        obj.hp_ = obj.hpLimit_;
        this.popMessage("恢复满血");
        this.alive_ = false;
    }
}


/******* 装备类********/
//装备看作是一类特殊的食物
//一个先锋盾为例，其他装备类可以继承此类，需要重写 init ,go, beHit, fire 方法即可 
//先锋盾,可以自动恢复生命 ，有一定概率闪避攻击, 增加声明上线
Tank.Equip = function(loc){
    Tank.Equip.superClass_.constructor.call(this, Tank.canvas_, "先锋盾", null, loc); 
    this.size_ = new Tank.Point(40, 40);
    this.isFood_ = true; //因为掉在地上的装备表现和食物相同
    var img = new Image();
    img.src = "img/equips/equip_0.gif";
    this.imgs_ = [img];
    this.isBarrier4Bullet_ = false;
    this.isBarrier4Walk_ = true;
    this.missProbility_ = 30; //有30%的概率躲避攻击
}

goog.inherits(Tank.Equip, Tank.BaseObject);
Tank.Equip.prototype.feed = function(obj){
    obj.equips_.push(this);
    this.obj_ = obj;
    this.obj_.popMessage("装备<" + this.name_ + ">");
    this.alive_ = false; //注意，此时会从地图上移除，但是在被装备的对象上仍然保存
    this.equip();
}
//穿上装备的时候触发此方法一次
Tank.Equip.prototype.equip= function(){
    this.obj_.hpLimit_ += 100; //生命上限 + 100
    this.obj_.setMissProb(50); //
    this.obj_.hpRecover_ += 5;  //生命回复 +5
}
Tank.Equip.prototype.go = function(){
    
}
Tank.Equip.prototype.tick = function(){
    if(this.obj_){
    }
}
Tank.Equip.prototype.beHit = function(obj){
    if(this.obj_){
        if(obj.power_ && obj.camp_ != this.obj_.camp_){

        }
    }
}

Tank.Equip.prototype.harm = function(num, obj){
}
Tank.Equip.prototype.fire = function(){
}

//大炮
//有一定概率造成4倍伤害,攻击 + 10
Tank.Equip1 = function(loc){
    Tank.Equip1.superClass_.constructor.call(this, loc);
    this.name_ = "大炮";
    var img = new Image();
    img.src = "img/equips/equip_1.jpg";
    this.imgs_ = [img];

}
goog.inherits(Tank.Equip1, Tank.Equip);
Tank.Equip1.prototype.equip = function(){
    this.obj_.bulletPower_ += 10;
    this.obj_.critProb_ += 20;//暴击概率 + 20
    this.obj_.crit_ += 100;  //暴击伤害+100%
}
Tank.Equip1.prototype.go = function(){
    
}
Tank.Equip1.prototype.beHit = function(obj){
    
}
Tank.Equip1.prototype.fire = function(){
    if(this.obj_){
    }
}

/*** 飞鞋 ****/
//增加2点移动速度
Tank.Equip2 = function(loc){
    Tank.Equip2.superClass_.constructor.call(this, loc);
    this.name_ = "飞鞋";
    var img = new Image();
    img.src = "img/equips/equip_2.jpg";
    this.imgs_ = [img];

}
goog.inherits(Tank.Equip2, Tank.Equip);
Tank.Equip2.prototype.equip = function(){
    this.obj_.moveSpeed_ += 2;
}
Tank.Equip2.prototype.go = function(){
    
}
Tank.Equip2.prototype.beHit = function(obj){
    
}
Tank.Equip2.prototype.fire = function(){
}

//辉耀
//增加10点攻击，每秒对150半径类的敌人造成10点伤害
Tank.Equip3 = function(loc){
    Tank.Equip3.superClass_.constructor.call(this, loc);
    this.name_ = "辉耀";
    var img = new Image();
    img.src = "img/equips/equip_3.jpg";
    this.imgs_ = [img];

}
goog.inherits(Tank.Equip3, Tank.Equip);
Tank.Equip3.prototype.equip = function(){
    this.obj_.bulletPower_ += 10;
}
//每秒对周围敌人造成伤害,不会对中立单位造成伤害
Tank.Equip3.prototype.tick = function(){
    if(this.obj_){
        var objs = Tank.SceneManager.getObjsInScope( this.obj_.loc_, 150);
        for(i in objs){
            if(objs[i].camp_ != 0 && objs[i].camp_ != this.obj_.camp_){
                objs[i].beHarmed(10, this, true);
            }
        }
    }
}
Tank.Equip3.prototype.go = function(){
    
}
Tank.Equip3.prototype.beHit = function(obj){
    
}
Tank.Equip3.prototype.fire = function(){
}

/** 死亡面罩****/
//对敌人造成伤害的 15% 恢复自己的生命
Tank.Equip4 = function(loc){
    Tank.Equip4.superClass_.constructor.call(this, loc);
    this.name_ = "死亡面罩";
    var img = new Image();
    img.src = "img/equips/equip_4.jpg";
    this.imgs_ = [img];

}
goog.inherits(Tank.Equip4, Tank.Equip);

Tank.Equip4.prototype.equip = function(){

}
Tank.Equip4.prototype.tick = function(){
}
Tank.Equip4.prototype.go = function(){
    
}
Tank.Equip4.prototype.harm = function(num, obj){
    if(this.obj_){
        if(!obj.isFood_ && obj.camp_ != 0 ){
            this.obj_.cure(parseInt(num/100*15), true);
        }
    }
}
Tank.Equip4.prototype.beHit = function(obj){
    
}
Tank.Equip4.prototype.fire = function(){
}

/*******RandomTank*****/
Tank.RandomTank = function(loc){
    Tank.RandomTank.superClass_.constructor.call(this, Tank.canvas_);
    this.loc_ = new Tank.Point(loc);
    this.canEatFood_ = false;
    this.moveDirec_ = 2;
    this.moving_ = true;
    this.camp_ = 2;
    this.showBloodBar_ = true;
    this.isBarrier4Bullet_ = true;
    this.hp_ = this.hpLimit_ = 100;
    this.ais_.push(new Tank.RandomMoveAI(this));
    this.ais_.push(new Tank.RandomFireAI(this));
}
goog.inherits(Tank.RandomTank, Tank.FireMovable);
Tank.RandomTank.prototype.die = function(){
    Tank.RandomTank.superClass_.die.call(this);
    Tank.SceneManager.push(new Tank.Explode(new Tank.Point(this.loc_)));//临死前，发生爆炸
    Tank.SceneManager.push(new Tank.Food(new Tank.Point(this.loc_.x + 50, this.loc_.y)));//临死前，掉个大膏药
}



/******maintank******/
Tank.MainTank = function(){
    Tank.MainTank.superClass_.constructor.call(this, Tank.canvas_);
    this.showBloodBar_ = true;
    this.hp_ = this.hpLimit_ = 200;
    this.hp_ = 50;
    this.camp_ = 1;
    this.canEatFood_ = true;
    this.protect_ = 1;
    this.loc_ = new Tank.Point(400, 500);
    this.ais_.push(new Tank.KeyAI(this));
    this.bulletPower_  = 20;
}
goog.inherits(Tank.MainTank, Tank.FireMovable);
