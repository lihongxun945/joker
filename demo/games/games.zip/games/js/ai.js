/**
提供一个ai父类，以及若干个子类

  */

/* 
   ai父类

obj: 拥有此ai的物体
*/

Tank.AI = function(obj){
    this.obj_  = obj;
}
goog.inherits(Tank.AI, goog.ui.Component);

Tank.AI.prototype.go = function() {}
Tank.AI.prototype.tick = function() {}
Tank.AI.prototype.beHit = function(obj){};
Tank.AI.prototype.hit = function(obj){};
Tank.AI.prototype.harm = function(num, obj){};


/**
    movable 类的基础ai
  */
Tank.MovableAI = function(obj){
    Tank.MovableAI.superClass_.constructor.call(this, obj);
}
goog.inherits(Tank.MovableAI, Tank.AI);
Tank.MovableAI.prototype.hit = function(obj){
    if(obj.isFood_){
        if(this.obj_.canEatFood_)
            obj.feed(this.obj_);
    }else if(this.obj_.camp_ != obj.camp_ && obj.isBarrier4Walk_ && !obj.isBullet_){
        this.obj_.loc_ = new Tank.Point(this.obj_.lastLoc_);
    }
}
Tank.MovableAI.prototype.go = function(){
   this.obj_.lastLoc_ = new Tank.Point(this.obj_.loc_);
   this.obj_.imgs_ = this.obj_.imgsAll_[this.obj_.moveDirec_];
   if(this.obj_.moving_ && this.obj_.enableMove_){
       switch(this.obj_.moveDirec_){
            case(0):
                this.obj_.loc_.y -= this.obj_.moveSpeed_;
                break;
            case(1):
                this.obj_.loc_.x += this.obj_.moveSpeed_;
                break;
            case(2):
                this.obj_.loc_.y += this.obj_.moveSpeed_;
                break;
            case(3):
                this.obj_.loc_.x -= this.obj_.moveSpeed_;
                break;

       }
   }
    if(this.obj_.loc_.x < 0 || this.obj_.loc_.y < 0 || this.obj_.loc_.x + this.obj_.size_.x > Tank.size_.x ||
            this.obj_.loc_.y + this.obj_.size_.y > Tank.size_.y) {
        this.obj_.alive_ = false;
    }
}

/*
   KeyAI 响应键盘事件
   */
Tank.KeyAI = function(obj){
    Tank.KeyAI.superClass_.constructor.call(this, obj); 
    this.getHandler().listen(Tank.listenBody_, goog.events.EventType.KEYDOWN, this.onKeyDown); 
    this.getHandler().listen(Tank.listenBody_, goog.events.EventType.KEYUP, this.onKeyUp); 

}
goog.inherits(Tank.KeyAI, Tank.AI);
Tank.KeyAI.prototype.go = function(){
    if(this.obj_.loc_.x < 0 || this.obj_.loc_.y < 0 || this.obj_.loc_.x + this.obj_.size_.x > Tank.size_.x ||
            this.obj_.loc_.y + this.obj_.size_.y > Tank.size_.y) {
        this.obj_.alive_ = true;
        this.obj_.loc_ = new Tank.Point(this.obj_.lastLoc_);
    }
}
Tank.KeyAI.prototype.onKeyDown = function(e){
    switch(e.keyCode){
        case(goog.events.KeyCodes.UP):
            this.obj_.move(0);
            break;
        case(goog.events.KeyCodes.RIGHT):
            this.obj_.move(1);
            break;
        case(goog.events.KeyCodes.DOWN):
            this.obj_.move(2);
            break;
        case(goog.events.KeyCodes.LEFT):
            this.obj_.move(3);
            break;
        case(goog.events.KeyCodes.A):
            this.obj_.startFire();;
            break;

    }
}
Tank.KeyAI.prototype.onKeyUp = function(e){
    switch(e.keyCode){
        case(goog.events.KeyCodes.UP):
            if(this.obj_.moveDirec_ == 0)
            this.obj_.stop();
            break;
        case(goog.events.KeyCodes.RIGHT):
            if(this.obj_.moveDirec_ == 1)
            this.obj_.stop();
            break;
        case(goog.events.KeyCodes.DOWN):
            if(this.obj_.moveDirec_ == 2)
            this.obj_.stop();
            break;
        case(goog.events.KeyCodes.LEFT):
            if(this.obj_.moveDirec_ == 3)
            this.obj_.stop();
            break;
        case(goog.events.KeyCodes.A):
            this.obj_.stopFire();
            break;
    }
}


/*
   随机的走动,碰到障碍物后会随机的改变方向
*/
Tank.RandomMoveAI = function(obj){
    Tank.RandomMoveAI.superClass_.constructor.call(this, obj);
    this.autoTurnProbility_ = 100;
}
goog.inherits(Tank.RandomMoveAI, Tank.AI);
Tank.RandomMoveAI.prototype.go = function(){
    if(this.obj_.loc_.x < 0 || this.obj_.loc_.y < 0 || this.obj_.loc_.x + this.obj_.size_.x > Tank.size_.x ||
            this.obj_.loc_.y + this.obj_.size_.y > Tank.size_.y) {
        this.obj_.alive_ = true;
        this.obj_.loc_ = new Tank.Point(this.obj_.lastLoc_);
        this.randomTurn();
    }else{
        var i = parseInt(Math.random() * this.autoTurnProbility_);
        if(i == 1){
            this.randomTurn();
        }
    }
}
Tank.RandomMoveAI.prototype.randomTurn = function(){
    var i = parseInt(Math.random() * 4); 
    this.obj_.moveDirec_ = i;
}
Tank.RandomMoveAI.prototype.hit = function(obj){
    if(obj.isBarrier4Walk_ && (obj.camp_ != this.obj_.camp_) && !obj.isFood_ && !obj.isBullet_){
        this.randomTurn();
    }
}

/*
    随机fire ai
   */
Tank.RandomFireAI = function(obj){
    Tank.RandomFireAI.superClass_.constructor.call(this, obj);
    this.autoFireProbility_ = 20;
}
goog.inherits(Tank.RandomFireAI, Tank.AI);
Tank.RandomFireAI.prototype.go = function(){
    var i = parseInt(Math.random() * this.autoFireProbility_);
    if(i == 1){
        this.obj_.firing_ = true;
    }else {
        this.obj_.firing_ = false;
    }
}
